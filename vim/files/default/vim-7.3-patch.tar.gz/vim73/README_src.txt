README_src.txt for version 7.3 of Vim: Vi IMproved.

The source archive contains the files needed to compile Vim on Unix systems.
It is packed for Unix systems (NL line separator).  It is also used for other
systems in combination with the extra archive (vim-7.3-extra.tar.gz, in the
"extra" directory of ftp.vim.org).

For more information, see the README.txt file that comes with the runtime
archive (vim-7.3-rt.tar.gz).  To be able to run Vim you MUST get the runtime
archive too!
